from flask import Flask
from src.controller import *

app = Flask(__name__)
app.config.from_mapping(
    SECRET_KEY = 'development'
)
app.add_url_rule(routes["index_route"], view_func=routes["index_controller"])
app.add_url_rule(routes["cadastrar_cliente_route"], view_func=routes["cadastrar_cliente_controller"])
app.add_url_rule(routes["cadastrar_estoque_route"], view_func=routes["cadastrar_estoque_controller"])
app.add_url_rule(routes["cadastrar_venda_route"], view_func=routes["cadastrar_venda_controller"])
app.add_url_rule(routes["listar_cliente_route"], view_func=routes["listar_cliente_controller"])
app.add_url_rule(routes["listar_estoque_route"], view_func=routes["listar_estoque_controller"])
app.add_url_rule(routes["listar_venda_route"], view_func=routes["listar_venda_controller"])
app.add_url_rule(routes["editar_cliente_route"], view_func=routes["editar_cliente_controller"])
app.add_url_rule(routes["editar_estoque_route"], view_func=routes["editar_estoque_controller"])
app.add_url_rule(routes["deletar_cliente_route"], view_func=routes["deletar_cliente_controller"])
app.add_url_rule(routes["deletar_estoque_route"], view_func=routes["deletar_estoque_controller"])
app.add_url_rule(routes["atualizar_cliente_route"], view_func=routes["atualizar_cliente_controller"])
app.add_url_rule(routes["atualizar_estoque_route"], view_func=routes["atualizar_estoque_controller"])