function redirecionarParaClientes() {
    window.location.href = '/listar/cliente';
}

function redirecionarParaEstoque(){
    window.location.href = '/listar/estoque';
}

function redirecionarParaVendas(){
    window.location.href = '/listar/venda';
}

