from flask.views import MethodView
from flask import request, render_template, redirect,flash
from src.database.config_db import mysql

class CadastrarClienteControlle(MethodView):
    def post(self):
        nome = request.form['nome']
        with mysql.cursor()as cur:
            try:
                comando = f'INSERT INTO clientes (nome) VALUES ("{nome}")'
                cur.execute(comando)
                cur.connection.commit()
                flash('Cliente cadastrado com sucesso.', 'success')
            except:
                flash('Não foi possível cadastrar o cliente.', 'error') 
        return redirect('/listar/cliente')
    
class CadastrarEstoqueController(MethodView):
    def post(self):
        nome_produto = request.form['nome_produto']
        quantidade_disponivel = request.form['quantidade_disponivel']
        preco_unitario = request.form['preco_unitario']

        with mysql.cursor()as cur:
            try:
                comando = f'INSERT INTO estoque (nome_produto, quantidade_disponivel, preco_unitario) VALUES ("{nome_produto}", "{quantidade_disponivel}", "{preco_unitario}")'
                cur.execute(comando)
                cur.connection.commit()
                flash('Produto cadastrado com sucesso.', 'success')
            except:
                flash('Não foi possível cadastrar este produto.', 'error') 
        return redirect('/listar/estoque')
    
class CadastrarVendaController(MethodView):
    def post(self):
        venda_idProduto = request.form['venda_idProdutos']
        venda_idCliente = request.form['venda_idClientes']
        quantidade_vendida = request.form['quantidade_vendida']

        with mysql.cursor()as cur:
            try:
                comando = f'INSERT INTO vendas (id_cliente, id_produto, quantidade_vendida) VALUES ({venda_idCliente},{venda_idProduto},{quantidade_vendida})'
                cur.execute(comando)
                cur.connection.commit()
                flash('Venda cadastrada com sucesso.', 'success')
            except:
                flash('Não foi possível cadastrar a venda.', 'error') 
        return redirect('/listar/venda')

class IndexController(MethodView):
    def get(self):
        return render_template('public/index.html')
    
class ListarClienteControlle(MethodView):
    def get(self):
        with mysql.cursor() as cur:
            cur.connection.commit()
            comando = f'SELECT * FROM clientes order by nome'
            cur.execute(comando)
            dados_cliente = cur.fetchall()

        return render_template('public/clientes.html', dados_cliente=dados_cliente)

class ListarEstoqueController(MethodView):
    def get(self):
        with mysql.cursor() as cur:
            cur.connection.commit()
            comando = f'SELECT * FROM estoque'
            cur.execute(comando)
            dados_estoque = cur.fetchall()
  
        return render_template('public/estoque.html', dados_estoque=dados_estoque)
    

class ListarVendaController(MethodView):
    def get(self):
        with mysql.cursor() as cur:
            cur.connection.commit()
            comando = f'SELECT clientes.id_cliente, clientes.nome AS nome_cliente, SUM(vendas.quantidade_vendida * estoque.preco_unitario) AS valor_total_vendas FROM vendas JOIN clientes ON clientes.id_cliente = vendas.id_cliente JOIN estoque ON estoque.id_produto = vendas.id_produto GROUP BY clientes.id_cliente, clientes.nome ORDER BY valor_total_vendas DESC'
            cur.execute(comando)
            dados_cliente_total = cur.fetchall()
        
            comando = f'SELECT clientes.nome, estoque.nome_produto, SUM(vendas.quantidade_vendida) AS total_quantidade_vendida FROM vendas JOIN estoque ON vendas.id_produto = estoque.id_produto JOIN clientes ON vendas.id_cliente = clientes.id_cliente GROUP BY clientes.nome, estoque.nome_produto ORDER BY clientes.nome'
            cur.execute(comando)
            dados_venda = cur.fetchall()
            
            comando = f'SELECT SUM(vendas.quantidade_vendida) total, estoque.nome_produto FROM vendas JOIN estoque ON vendas.id_produto = estoque.id_produto GROUP BY estoque.nome_produto ORDER BY total DESC'
            cur.execute(comando)
            dados_mais_vendidos = cur.fetchall()

            comando = f'SELECT * FROM clientes'
            cur.execute(comando)
            dados_cliente = cur.fetchall()

            comando = f'SELECT * FROM estoque ORDER BY quantidade_disponivel'
            cur.execute(comando)
            dados_produto = cur.fetchall()           
        return render_template('public/vendas.html', dados_venda=dados_venda, dados_cliente=dados_cliente, dados_produto=dados_produto, dados_mais_vendidos=dados_mais_vendidos, dados_cliente_total=dados_cliente_total)
    


class DeletarClienteController(MethodView):
    def post(self, id_cliente):
        with mysql.cursor() as cur:
            try:
                comando = f'DELETE FROM clientes WHERE id_cliente = {id_cliente}'
                cur.execute(comando)
                cur.connection.commit()
                flash('Cliente deletado com sucesso.', 'success')
            except:
                flash('Não foi possível deletar o cliente.', 'error')
        return redirect('/listar/cliente')

class DeletarEstoqueController(MethodView):
    def post(self, id_produto):
        with mysql.cursor() as cur:
            try:
                comando = f'DELETE FROM estoque WHERE id_produto = {id_produto}'
                cur.execute(comando)
                cur.connection.commit()
                flash('Estoque deletado com sucesso.', 'success')
            except:
                flash('Não foi possível deletar o estoque.', 'error')
        return redirect('/listar/estoque')
    
class EditarClienteController(MethodView):
    def post(self, id_cliente):
        with mysql.cursor() as cur:
            cur.connection.commit()
            comando = f'SELECT * FROM clientes WHERE id_cliente = {id_cliente}'
            cur.execute(comando)
            cliente = cur.fetchone()
            return render_template('public/atualizarcliente.html', id_cliente=cliente)
        
class EditarEstoqueController(MethodView):
    def post(self, id_produto):
        with mysql.cursor() as cur:
            cur.connection.commit()
            comando = f'SELECT * FROM estoque WHERE id_produto = {id_produto}'
            cur.execute(comando)
            dados_estoque = cur.fetchone()
            return render_template('public/atualizarestoque.html', id_produto=dados_estoque)

class AtualizarClienteController(MethodView):
    def post(self, id_cliente):
        nomeCliente = request.form['nome']
        with mysql.cursor() as cur:
            try:
                comando = f'UPDATE clientes SET nome = "{nomeCliente}" WHERE id_cliente = {id_cliente}' 
                cur.execute(comando)
                cur.connection.commit()
                flash('Cliente atualizado com sucesso', 'success')
            except:
                flash('Não foi possível atualizar o cliente.', 'error')
        return redirect('/listar/cliente')

class AtualizarEstoqueController(MethodView):
    def post(self, id_produto):
        produto_nome = request.form['nome_produto']
        produto_quantidade_disponivel = request.form['quantidade_disponivel']
        preco_unitario = request.form['preco_unitario']
        with mysql.cursor() as cur:
            try:
                comando = f'UPDATE estoque SET nome_produto = "{produto_nome}", quantidade_disponivel = {produto_quantidade_disponivel}, preco_unitario = {preco_unitario} WHERE id_produto = {id_produto}'
                cur.execute(comando)
                cur.connection.commit()
                flash('Estoque atualizado com sucesso', 'success')
            except:
                flash('Não foi possível atualizar o estoque.', 'error')
        return redirect('/listar/estoque')

routes = {
    "index_route":"/", "index_controller":IndexController.as_view("index"),
    "cadastrar_cliente_route":"/cadastrar/cliente","cadastrar_cliente_controller":CadastrarClienteControlle.as_view("cadastrar_cliente"),
    "cadastrar_estoque_route":"/cadastrar/estoque","cadastrar_estoque_controller":CadastrarEstoqueController.as_view("cadastrar_estoque"),
    "cadastrar_venda_route":"/cadastrar/venda","cadastrar_venda_controller":CadastrarVendaController.as_view("cadastrar_venda"),
    "listar_cliente_route":"/listar/cliente","listar_cliente_controller":ListarClienteControlle.as_view("listar_cliente"),
    "listar_estoque_route":"/listar/estoque","listar_estoque_controller":ListarEstoqueController.as_view("listar_estoque"),
    "listar_venda_route":"/listar/venda","listar_venda_controller":ListarVendaController.as_view("listar_venda"),
    "editar_cliente_route":"/editar/cliente/<int:id_cliente>","editar_cliente_controller":EditarClienteController.as_view("editar_cliente"),
    "editar_estoque_route":"/editar/estoque/<int:id_produto>","editar_estoque_controller":EditarEstoqueController.as_view("editar_estoque"),
    "deletar_cliente_route":"/deletar/cliente/<int:id_cliente>","deletar_cliente_controller":DeletarClienteController.as_view("deletar_cliente"),
    "deletar_estoque_route":"/deletar/estoque/<int:id_produto>","deletar_estoque_controller":DeletarEstoqueController.as_view("deletar_estoque"),
    "atualizar_cliente_route":"/atualizar/cliente/<int:id_cliente>","atualizar_cliente_controller":AtualizarClienteController.as_view("atualizar_cliente"),
    "atualizar_estoque_route":"/atualizar/estoque/<int:id_produto>","atualizar_estoque_controller":AtualizarEstoqueController.as_view("atualizar_estoque"),
}